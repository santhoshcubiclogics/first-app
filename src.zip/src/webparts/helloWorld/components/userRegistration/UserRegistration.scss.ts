/* tslint:disable */
require("./UserRegistration.css");
const styles = {

};

export default styles;
/* tslint:enable */