/* tslint:disable */
require("./ModalForm.css");
const styles = {

};

export default styles;
/* tslint:enable */