/* tslint:disable */
require("./HeaderComponent.css");
const styles = {

};

export default styles;
/* tslint:enable */