import React from 'react'

function AutomationComponent() {
  return (
    <div>
        
    </div>
  )
}

export default AutomationComponent